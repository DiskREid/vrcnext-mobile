import { uiMessage } from '../i18n';
import { t, useI18n, dateLocale } from '../i18n';
import { useEffect, useRef, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Bell,
  BellOff,
  CalendarDays,
  Check,
  Clock3,
  ExternalLink,
  ImageIcon,
  Info,
  Mail,
  RefreshCw,
  Send,
  Trash2,
  Upload,
  Users,
} from 'lucide-react';
import { api, native } from '../api';
import type {
  CalendarEvent,
  Group,
  InventoryItem,
  MessageTemplate,
  Notification,
  UploadTag,
  User,
  VrcFile,
} from '../api';
import { useApp, useLoad } from '../state';
import { demoEvents, demoFriends, demoWorlds } from '../demo';
import {
  AvatarImage,
  Badge,
  Empty,
  ErrorState,
  imageOf,
  Loading,
  Modal,
  PageHeader,
  SearchField,
  Segmented,
  Section,
} from '../components/ui';
import SecureImage from '../components/SecureImage';
import { FullscreenImageViewer } from '../components/FullscreenImageViewer';
import { printDate, printMedia } from '../api/prints';
import { createCalendarClient, withCalendarGroups } from '../api/calendar';
import { reconcilePage } from '../hooks/paged-data';
import type { Print } from '../api/prints';
import './Collections.css';

const dateLabel = (
  value?: string,
  options: Intl.DateTimeFormatOptions = {
    day: 'numeric',
    month: 'long',
    hour: '2-digit',
    minute: '2-digit',
  },
) => {
  if (!value) return t('Дата не указана');
  const date = new Date(value);
  return Number.isNaN(date.getTime())
    ? t('Дата не указана')
    : date.toLocaleString(dateLocale(), options);
};
const localDay = (date: Date) =>
  `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
const eventStart = (event: CalendarEvent) =>
  event.startsAt || ('startDate' in event ? String(event.startDate || '') : '');
const eventEnd = (event: CalendarEvent) =>
  event.endsAt || ('endDate' in event ? String(event.endDate || '') : '');
function occursOn(event: CalendarEvent, day: Date) {
  const start = new Date(eventStart(event));
  if (Number.isNaN(start.getTime())) return false;
  const next = new Date(day.getFullYear(), day.getMonth(), day.getDate() + 1);
  const end = new Date(eventEnd(event));
  return (
    start < next &&
    (Number.isNaN(end.getTime()) || end <= start ? localDay(start) === localDay(day) : end > day)
  );
}

const calendarClient = createCalendarClient(api.request);
type CalendarWindow = {
  key: string;
  events: CalendarEvent[];
  hasNext: boolean;
  nextOffset: number;
  pages: number;
  warning: string;
};

export function CalendarPage() {
  useI18n();
  const ctx = useApp();
  const [month, setMonth] = useState(
    () => new Date(new Date().getFullYear(), new Date().getMonth(), 1),
  );
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [filter, setFilter] = useState<'all' | 'following'>('all');
  const [selected, setSelected] = useState<CalendarEvent | null>(null);
  const [moreLoading, setMoreLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [page, setPage] = useState<CalendarWindow>();
  const key = `${ctx.user.id}:${ctx.demo}:${month.getFullYear()}:${month.getMonth()}:${filter}`;
  const latestKey = useRef(key);
  latestKey.current = ctx.pageActive === false ? '' : key;
  const scope = `${key}:${ctx.pageActive !== false}`;
  const observation = useRef({ scope, generation: 0 });
  if (observation.current.scope !== scope)
    observation.current = { scope, generation: observation.current.generation + 1 };
  useEffect(() => {
    if (ctx.pageActive === false) setSelected(null);
  }, [ctx.pageActive]);
  const window = useRef({ key: '', pages: 1 });
  const load = useLoad<CalendarWindow>(async () => {
    const generation = observation.current.generation;
    const isCurrent = () =>
      latestKey.current === key && observation.current.generation === generation;
    setRefreshing(true);
    try {
      const pages = window.current.key === key ? window.current.pages : 1;
      let offset = 0,
        hasNext = false,
        completed = 0;
      const events: CalendarEvent[] = [];
      if (ctx.demo) {
        events.push(...demoEvents.filter((event) => filter !== 'following' || event.isFollowing));
        completed = 1;
      } else
        for (let index = 0; index < pages; index++) {
          if (!isCurrent()) break;
          const result = await calendarClient.month(month, filter, offset);
          if (!isCurrent()) break;
          const seen = new Set(events.map((event) => event.id));
          const additions = result.events.filter((event) => !seen.has(event.id));
          if (index && result.hasNext && !additions.length)
            throw new Error(t('VRChat повторил страницу календаря.'));
          events.push(...additions);
          completed++;
          offset = result.nextOffset;
          hasNext = result.hasNext;
          if (!hasNext) break;
        }
      let groups: Group[] = [],
        warning = '';
      if (!ctx.demo && isCurrent())
        try {
          groups = await calendarClient.groups(ctx.user.id);
        } catch (error) {
          warning =
            error instanceof Error ? error.message : t('Не удалось загрузить названия групп.');
        }
      return {
        key,
        events: withCalendarGroups(events, groups),
        hasNext,
        nextOffset: offset,
        pages: completed,
        warning,
      };
    } finally {
      if (isCurrent()) setRefreshing(false);
    }
  }, [key, ctx.refresh]);
  useEffect(() => {
    if (load.data?.key !== key) return;
    const fresh = load.data;
    window.current = { key, pages: fresh.pages };
    setPage((old) => ({
      ...fresh,
      events: old?.key === key ? reconcilePage(old.events, fresh.events) : fresh.events,
    }));
  }, [load.data, key]);
  const current = page?.key === key ? page : undefined;
  const events = current?.events || [];
  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const preceding = (month.getDay() + 6) % 7;
  const days = Array.from(
    { length: daysInMonth },
    (_, index) => new Date(month.getFullYear(), month.getMonth(), index + 1),
  );
  const visible = events
    .filter((event) =>
      selectedDay
        ? days.some((day) => localDay(day) === selectedDay && occursOn(event, day))
        : days.some((day) => occursOn(event, day)),
    )
    .sort((a, b) => Date.parse(eventStart(a)) - Date.parse(eventStart(b)));
  function moveMonth(direction: number) {
    setSelectedDay(null);
    setMonth(new Date(month.getFullYear(), month.getMonth() + direction, 1));
  }
  async function loadMore() {
    if (!current || moreLoading || refreshing || ctx.pageActive === false) return;
    const captured = key;
    const generation = observation.current.generation;
    const isCurrent = () =>
      latestKey.current === captured && observation.current.generation === generation;
    setMoreLoading(true);
    try {
      const next = await calendarClient.month(month, filter, current.nextOffset);
      if (!isCurrent()) return;
      const names = current.events.flatMap((event) => (event.group ? [event.group] : []));
      const existing = new Set(current.events.map((event) => event.id));
      const additions = withCalendarGroups(next.events, names).filter(
        (event) => !existing.has(event.id),
      );
      if (next.hasNext && !additions.length)
        throw new Error(t('VRChat повторил страницу календаря.'));
      window.current = { key, pages: current.pages + 1 };
      setPage({
        ...current,
        events: [...current.events, ...additions],
        nextOffset: next.nextOffset,
        hasNext: next.hasNext,
        pages: current.pages + 1,
      });
    } catch (error) {
      if (isCurrent())
        ctx.notify(error instanceof Error ? error.message : t('Не удалось загрузить события'));
    } finally {
      setMoreLoading(false);
    }
  }
  return (
    <>
      <PageHeader
        eyebrow={t('ВСТРЕЧАЕМСЯ В VRCHAT')}
        title={t('Календарь')}
        subtitle={t('События ваших групп и новые встречи.')}
        actions={
          <button
            className="icon-button"
            aria-label={t('Обновить календарь')}
            onClick={load.reload}
            disabled={refreshing || moreLoading}
            aria-busy={refreshing}
          >
            <RefreshCw size={19} className={refreshing ? 'spin' : undefined} />
          </button>
        }
      />
      <div className="toolbar">
        <Segmented
          items={[
            { id: 'all', label: t('Все события') },
            { id: 'following', label: t('Подписки') },
          ]}
          value={filter}
          onChange={(value) => {
            setFilter(value as 'all' | 'following');
            setSelectedDay(null);
          }}
        />
      </div>
      {load.error && <ErrorState error={load.error} retry={load.reload} />}
      {current?.warning && <ErrorState error={current.warning} retry={load.reload} />}
      <div className="calendar-layout">
        <section className="card calendar-card" aria-label={t('Календарь месяца')}>
          <div className="calendar-month-row">
            <button
              className="icon-button"
              aria-label={t('Предыдущий месяц')}
              onClick={() => moveMonth(-1)}
            >
              <ArrowLeft size={19} />
            </button>
            <h2>{month.toLocaleDateString(dateLocale(), { month: 'long', year: 'numeric' })}</h2>
            <button
              className="icon-button"
              aria-label={t('Следующий месяц')}
              onClick={() => moveMonth(1)}
            >
              <ArrowRight size={19} />
            </button>
          </div>
          <div className="calendar-weekdays" aria-hidden="true">
            {[t('Пн'), t('Вт'), t('Ср'), t('Чт'), t('Пт'), t('Сб'), t('Вс')].map((day) => (
              <span key={day}>{day}</span>
            ))}
          </div>
          <div className="calendar-grid">
            {Array.from({ length: preceding }, (_, i) => (
              <span key={`blank-${i}`} />
            ))}
            {days.map((day) => {
              const date = localDay(day),
                count = events.filter((event) => occursOn(event, day)).length,
                today = date === localDay(new Date());
              return (
                <button
                  key={date}
                  onClick={() => setSelectedDay(selectedDay === date ? null : date)}
                  className={`calendar-day ${selectedDay === date ? 'selected' : ''} ${today ? 'today' : ''}`}
                  aria-pressed={selectedDay === date}
                  aria-label={t('{value0}, событий: {value1}{value2}', {
                    value0: day.toLocaleDateString(dateLocale(), { day: 'numeric', month: 'long' }),
                    value1: count,
                    value2: today ? t(', сегодня') : '',
                  })}
                >
                  <span>{day.getDate()}</span>
                  {count > 0 && <i aria-hidden="true" />}
                </button>
              );
            })}
          </div>
          <div className="calendar-footer">
            <button
              className="text-button"
              onClick={() => {
                setMonth(new Date(new Date().getFullYear(), new Date().getMonth(), 1));
                setSelectedDay(localDay(new Date()));
              }}
            >
              {t('Сегодня')}
            </button>
            {selectedDay && (
              <button className="text-button" onClick={() => setSelectedDay(null)}>
                {t('Весь месяц')}
              </button>
            )}
          </div>
          <p className="calendar-timezone muted">
            <Clock3 size={13} />
            {t('Время: ')}
            {Intl.DateTimeFormat().resolvedOptions().timeZone}
          </p>
        </section>
        <Section
          title={
            selectedDay
              ? new Date(`${selectedDay}T12:00:00`).toLocaleDateString(dateLocale(), {
                  day: 'numeric',
                  month: 'long',
                })
              : t('События месяца')
          }
        >
          {!current && !load.error ? (
            <Loading />
          ) : !visible.length && !load.error ? (
            <Empty
              title={t('Свободный день')}
              text={
                ctx.demo
                  ? t('Демособытие появится в календаре завтрашнего дня.')
                  : t('Событий не найдено. Попробуйте другой день или фильтр.')
              }
              icon={<CalendarDays size={32} />}
            />
          ) : (
            <div className="event-list">
              {visible.map((event) => (
                <button
                  key={event.id}
                  className="card event-card"
                  onClick={() => setSelected(event)}
                >
                  <div className="event-date">
                    <span>
                      {new Date(eventStart(event)).toLocaleDateString(dateLocale(), {
                        month: 'short',
                      })}
                    </span>
                    <strong>{new Date(eventStart(event)).getDate()}</strong>
                  </div>
                  <div className="event-content">
                    <div className="row">
                      <h3>{event.title || event.name || t('Событие VRChat')}</h3>
                      {event.isFollowing && <Bell size={15} aria-label={t('Вы подписаны')} />}
                    </div>
                    <p className="muted">
                      {dateLabel(eventStart(event), { hour: '2-digit', minute: '2-digit' })}
                      {event.group?.name && ` · ${event.group.name}`}
                    </p>
                    {event.description && <p className="event-excerpt">{event.description}</p>}
                  </div>
                </button>
              ))}
            </div>
          )}
          {current?.hasNext && (
            <button
              className="button secondary load-more"
              disabled={moreLoading || refreshing}
              onClick={() => void loadMore()}
            >
              {moreLoading ? t('Загрузка…') : t('Ещё события')}
            </button>
          )}
        </Section>
      </div>
      {selected && ctx.pageActive !== false && (
        <CalendarEventDetail
          initial={selected}
          onClose={() => setSelected(null)}
          onChanged={(event) => {
            setSelected(event);
            setPage((old) =>
              old
                ? {
                    ...old,
                    events: old.events.map((item) => (item.id === event.id ? event : item)),
                  }
                : old,
            );
          }}
        />
      )}
    </>
  );
}

export function CalendarEventDetail(props: {
  initial: CalendarEvent;
  onClose: () => void;
  onChanged?: (event: CalendarEvent) => void;
}) {
  useI18n();
  return (
    <CalendarDetail
      key={`${props.initial.groupId || props.initial.ownerId}:${props.initial.id}`}
      {...props}
    />
  );
}
function CalendarDetail({
  initial,
  onClose,
  onChanged,
}: {
  initial: CalendarEvent;
  onClose: () => void;
  onChanged?: (event: CalendarEvent) => void;
}) {
  useI18n();
  const ctx = useApp();
  const [pending, setPending] = useState(false),
    [event, setEvent] = useState(initial);
  const groupId = initial.groupId || initial.group?.id || initial.ownerId;
  const detail = useLoad(async () => {
    if (ctx.demo) return initial;
    if (!groupId?.startsWith('grp_'))
      throw new Error(t('VRChat не передал группу события. Подробности недоступны.'));
    const fresh = await calendarClient.detail(groupId, initial.id);
    return {
      ...initial,
      ...fresh,
      groupId: fresh.groupId || groupId,
      isFollowing: fresh.isFollowing ?? initial.isFollowing,
    };
  }, [initial.id, groupId, ctx.demo]);
  const group = useLoad(async () => {
    if (ctx.demo) return initial.group;
    if (!groupId?.startsWith('grp_')) return undefined;
    const ownGroups = await calendarClient.groups(ctx.user.id);
    return ownGroups.find((item) => item.id === groupId) || api.group(groupId);
  }, [groupId, ctx.user.id, ctx.demo]);
  useEffect(() => {
    if (detail.data) setEvent(detail.data);
  }, [detail.data]);
  async function follow() {
    if (!groupId?.startsWith('grp_')) {
      ctx.notify(t('Группа события недоступна.'));
      return;
    }
    setPending(true);
    await ctx.act(
      async () => {
        const desired = !event.isFollowing;
        let fresh = await api.followEvent(groupId, event.id, desired);
        if (typeof fresh.isFollowing !== 'boolean')
          fresh = await calendarClient.detail(groupId, event.id);
        if (fresh.isFollowing !== desired)
          throw new Error(
            t('VRChat не подтвердил изменение подписки. Обновите событие и попробуйте ещё раз.'),
          );
        const next = { ...event, ...fresh, groupId: fresh.groupId || groupId };
        setEvent(next);
        onChanged?.(next);
        ctx.calendarSync.refresh();
      },
      event.isFollowing
        ? uiMessage('Подписка на событие отменена')
        : uiMessage('Вы подписались на событие'),
    );
    setPending(false);
  }
  return (
    <Modal title={event.title || event.name || t('Событие VRChat')} onClose={onClose}>
      {detail.loading && <Loading />}
      {detail.error && <ErrorState error={detail.error} retry={detail.reload} />}
      {group.error && <ErrorState error={group.error} retry={group.reload} />}
      {event.imageUrl && (
        <SecureImage className="collection-detail-image" src={event.imageUrl} alt="" />
      )}
      <div className="form-stack">
        <p className="row">
          <CalendarDays size={18} />
          {dateLabel(eventStart(event))}
        </p>
        {eventEnd(event) && (
          <p className="muted">
            {t('До ')}
            {dateLabel(eventEnd(event))}
          </p>
        )}
        {(group.data?.name || event.group?.name) && (
          <Badge>{group.data?.name || event.group?.name}</Badge>
        )}
        <p className="collection-description">
          {event.description || t('Организатор не добавил описание.')}
        </p>
        <div className="detail-actions">
          <button
            className="button"
            disabled={pending || detail.loading || !!detail.error || !groupId}
            onClick={() => void follow()}
          >
            {event.isFollowing ? <BellOff size={17} /> : <Bell size={17} />}
            {pending ? t('Сохранение…') : event.isFollowing ? t('Отписаться') : t('Подписаться')}
          </button>
          {groupId && (
            <button
              className="button secondary"
              onClick={() => {
                onClose();
                ctx.openGroup(group.data || event.group || { id: groupId, name: groupId });
              }}
            >
              {t('Открыть группу')}
            </button>
          )}
          {event.worldId && (
            <button
              className="button secondary"
              onClick={() => {
                onClose();
                ctx.openWorld(event.worldId!);
              }}
            >
              {t('Открыть мир')}
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}

type InventoryTab = UploadTag | 'prints' | 'inventory';
type CollectionItem = {
  id: string;
  name: string;
  nameFallback?: string;
  image: string;
  sourceUrl?: string;
  createdAt?: string;
  tags: string[];
  size?: number;
  kind: InventoryTab;
  worldId?: string;
  worldName?: string;
  authorName?: string;
};
const inventoryTabs: { id: InventoryTab; label: string }[] = [
  { id: 'gallery', label: 'Фото' },
  { id: 'icon', label: 'Иконки' },
  { id: 'emoji', label: 'Эмодзи' },
  { id: 'sticker', label: 'Стикеры' },
  { id: 'prints', label: 'Принты' },
  { id: 'inventory', label: 'Предметы' },
];
// Keep API names unchanged; translate only our fallback when the row renders.
const collectionName = (item: CollectionItem) =>
  item.name || t(item.nameFallback || 'Без названия');
function fileItem(file: VrcFile, kind: InventoryTab): CollectionItem {
  const versions = [...(file.versions || [])].reverse();
  const version =
    versions.find(
      (item) => item.file?.url && (!('status' in item) || item.status === 'complete'),
    ) ||
    versions.find((item) => item.file?.url) ||
    versions[0];
  const sourceUrl = version?.file?.url || file.fileUrl || '';
  return {
    id: file.id,
    sourceUrl,
    name: file.note || file.name || '',
    nameFallback: kind === 'prints' ? 'Принт VRChat' : 'Без названия',
    image:
      file.fileUrl ||
      file.imageUrl ||
      file.thumbnailImageUrl ||
      file.image?.url ||
      version?.file?.url ||
      version?.image?.url ||
      '',
    createdAt: file.created_at || file.createdAt || version?.created_at,
    tags: file.tags || [],
    size: version?.file?.sizeInBytes,
    kind,
    worldId: 'worldId' in file ? String(file.worldId || '') : undefined,
    worldName: 'worldName' in file ? String(file.worldName || '') : undefined,
  };
}
function inventoryItem(item: InventoryItem): CollectionItem {
  return {
    id: item.id,
    name: item.name || item.template?.name || '',
    nameFallback: 'Предмет VRChat',
    image: item.imageUrl || item.template?.imageUrl || '',
    tags: [item.itemType || item.template?.itemType || ''].filter(Boolean),
    kind: 'inventory',
  };
}
function printItem(print: Print): CollectionItem {
  const media = printMedia(print);
  return {
    id: print.id,
    name: print.note || '',
    nameFallback: 'Принт VRChat',
    image: media.thumbnail,
    sourceUrl: media.original,
    createdAt: printDate(print),
    tags: [],
    kind: 'prints',
    worldId: print.worldId,
    worldName: print.worldName,
    authorName: print.authorName,
  };
}

function CollectionPreview({
  src,
  alt,
  refreshKey,
  interactive = false,
  onOpen,
}: {
  src: string;
  alt: string;
  refreshKey: string;
  interactive?: boolean;
  onOpen?: () => void;
}) {
  useI18n();
  const [failed, setFailed] = useState(false);
  const [attempt, setAttempt] = useState(0);
  useEffect(() => setFailed(false), [src, refreshKey]);
  if (!src) return <span className="collection-media-status">{t('Изображение недоступно')}</span>;
  return (
    <>
      <SecureImage
        src={src}
        alt={alt}
        refreshKey={`${refreshKey}:${attempt}`}
        loading={interactive ? 'eager' : 'lazy'}
        onLoadError={() => setFailed(true)}
        onLoad={() => setFailed(false)}
        role={onOpen ? 'button' : undefined}
        tabIndex={onOpen ? 0 : undefined}
        aria-label={onOpen ? t('На весь экран: {value0}', { value0: alt }) : undefined}
        onClick={onOpen}
        onKeyDown={(event) => {
          if (onOpen && (event.key === 'Enter' || event.key === ' ')) {
            event.preventDefault();
            onOpen();
          }
        }}
        style={failed ? { visibility: 'hidden' } : undefined}
      />
      {failed && (
        <span className="collection-media-status" role="status">
          {t('Не удалось загрузить изображение.')}
          {interactive ? (
            <button
              className="button secondary"
              onClick={() => {
                setFailed(false);
                setAttempt((value) => value + 1);
              }}
            >
              <RefreshCw size={16} />
              {t(' Повторить')}
            </button>
          ) : (
            <span>{t('Откройте карточку, чтобы повторить.')}</span>
          )}
        </span>
      )}
    </>
  );
}
function validProfileImage(item: CollectionItem) {
  if (!item.sourceUrl || !item.id.startsWith('file_')) return false;
  try {
    const url = new URL(item.sourceUrl);
    return (
      url.protocol === 'https:' &&
      !url.username &&
      !url.password &&
      [
        'api.vrchat.cloud',
        'api.vrchat.com',
        'vrchat.com',
        'cloud.vrchat.cloud',
        'cloud.vrchat.com',
      ].includes(url.hostname) &&
      /\/file\/file_[a-zA-Z0-9-]+\/\d+\/file$/.test(url.pathname)
    );
  } catch {
    return false;
  }
}
function fileSize(size?: number) {
  return size === undefined
    ? ''
    : size < 1024 * 1024
      ? t('{value0} КБ', { value0: Math.round(size / 1024) })
      : t('{value0} МБ', { value0: (size / 1024 / 1024).toFixed(1) });
}

export function InventoryPage() {
  useI18n();
  const { user, demo, act, notify, refresh, openWorld, onUserUpdated } = useApp();
  const [tab, setTab] = useState<InventoryTab>('gallery');
  const [items, setItems] = useState<CollectionItem[]>([]);
  const [selected, setSelected] = useState<CollectionItem | null>(null);
  const [viewer, setViewer] = useState<{
    id: string;
    src: string;
    originalUrl?: string;
    title: string;
  } | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [appearanceAction, setAppearanceAction] = useState<'icon' | 'banner' | null>(null);
  const [busy, setBusy] = useState(false);
  const [hasMore, setHasMore] = useState(false);
  const [nextOffset, setNextOffset] = useState(100);
  const [upload, setUpload] = useState(false);
  const pageKey = `${user.id}:${tab}:${refresh}`;
  const latestKey = useRef(pageKey);
  latestKey.current = pageKey;
  const hasPlus = user.tags?.includes('system_supporter') || false;
  const canUpload = tab !== 'prints' && tab !== 'inventory';
  const plusRequired = tab === 'icon' || tab === 'emoji' || tab === 'sticker';
  async function fetchItems(offset: number): Promise<CollectionItem[]> {
    if (demo)
      return tab === 'gallery'
        ? demoWorlds.map((world, index) => ({
            id: `demo_photo_${index}`,
            name: world.name,
            image: world.imageUrl || '',
            createdAt: new Date(Date.now() - index * 86400000).toISOString(),
            tags: [],
            kind: 'gallery' as const,
          }))
        : [];
    if (tab === 'inventory') return (await api.inventory(offset)).map(inventoryItem);
    if (tab === 'prints') return (await api.prints(user.id, offset)).map(printItem);
    if (tab === 'emoji') {
      const [staticEmoji, animatedEmoji] = await Promise.all([
        api.files('emoji', offset),
        api.files('emojianimated', offset),
      ]);
      return Array.from(
        new Map(
          [...staticEmoji, ...animatedEmoji].map((item) => [item.id, fileItem(item, tab)]),
        ).values(),
      );
    }
    return (await api.files(tab, offset)).map((item) => fileItem(item, tab));
  }
  const load = useLoad<CollectionItem[]>(() => fetchItems(0), [pageKey, demo]);
  const [mediaRevision, setMediaRevision] = useState(0);
  function reload() {
    setMediaRevision((value) => value + 1);
    load.reload();
  }
  useEffect(() => {
    if (load.data) {
      setItems(load.data);
      setHasMore(!demo && load.data.length >= 100);
      setNextOffset(100);
    }
  }, [load.data, demo]);
  async function more() {
    const key = pageKey;
    setBusy(true);
    try {
      const next = await fetchItems(nextOffset);
      if (key === latestKey.current) {
        setItems((previous) => [
          ...previous,
          ...next.filter((item) => !previous.some((old) => old.id === item.id)),
        ]);
        setHasMore(next.length >= 100);
        setNextOffset((offset) => offset + 100);
      }
    } catch (error) {
      notify(error instanceof Error ? error.message : t('Не удалось загрузить следующую страницу'));
    } finally {
      setBusy(false);
    }
  }
  async function remove() {
    if (!selected) return;
    setBusy(true);
    const success = await act(async () => {
      if (selected.kind === 'prints') await api.deletePrint(selected.id);
      else await api.deleteFile(selected.id);
      return true;
    }, uiMessage('Файл удалён'));
    if (success) {
      setItems((previous) => previous.filter((item) => item.id !== selected.id));
      setSelected(null);
      setDeleteConfirm(false);
    }
    setBusy(false);
  }
  async function original() {
    if (!selected?.image) return;
    const item = selected;
    setViewer({
      id: item.id,
      src: item.image,
      originalUrl: item.sourceUrl || undefined,
      title: collectionName(item),
    });
    // A paged File can omit versions. Resolve real metadata rather than guessing /1/file.
    if (!demo && !item.sourceUrl && item.id.startsWith('file_')) {
      try {
        const file = fileItem(await api.file(item.id), item.kind);
        setViewer((previous) =>
          previous?.id === item.id
            ? { ...previous, originalUrl: file.sourceUrl || undefined }
            : previous,
        );
      } catch {
        /* Keep the available preview; do not pretend it is an original. */
      }
    }
  }
  async function applyAppearance() {
    if (!selected || !appearanceAction || !validProfileImage(selected)) return;
    const action = appearanceAction,
      fileUrl = selected.sourceUrl!;
    setBusy(true);
    try {
      const success = await act(
        async () => {
          await api.updateAppearance(
            user.id,
            action === 'icon'
              ? { userIcon: fileUrl }
              : { bannerType: 'customImage', bannerCustomUrl: fileUrl },
          );
          return true;
        },
        action === 'icon'
          ? uiMessage('Иконка профиля обновлена')
          : uiMessage('Баннер профиля обновлён'),
      );
      if (success) {
        setAppearanceAction(null);
        try {
          onUserUpdated(await api.resume());
        } catch {
          notify(t('Оформление сохранено в VRChat. Обновить локальный профиль пока не удалось.'));
        }
      }
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <PageHeader
        eyebrow={t('ВАШИ КОЛЛЕКЦИИ')}
        title={t('Инвентарь')}
        subtitle={t('Фото, иконки и небольшие вещи с большой историей.')}
        actions={
          <button
            className="icon-button"
            aria-label={t('Обновить инвентарь')}
            onClick={reload}
            disabled={load.loading}
          >
            <RefreshCw size={19} />
          </button>
        }
      />
      <div className="toolbar inventory-toolbar">
        <Segmented
          items={inventoryTabs.map((item) => ({ ...item, label: t(item.label) }))}
          value={tab}
          onChange={(value) => setTab(value as InventoryTab)}
        />
        {canUpload && (
          <button
            className="button"
            onClick={() => setUpload(true)}
            disabled={!demo && plusRequired && !hasPlus}
          >
            <Upload size={17} />
            {t(' Загрузить')}
          </button>
        )}
      </div>
      {plusRequired && (
        <p className="collection-note">
          <Info size={16} />
          {tab === 'icon' ? t('Иконки профиля') : t('Эмодзи и стикеры')}
          {t(' загружаются с подпиской VRC+.')}
          {(tab === 'emoji' || tab === 'sticker') && t(' Не больше 18 в коллекции.')}
        </p>
      )}
      {tab === 'prints' && (
        <p className="collection-note">
          <Info size={16} />
          {t(
            'Принты, созданные и собранные в VRChat. Фото с телефона можно загрузить во вкладке «Фото».',
          )}
        </p>
      )}
      {load.loading ? (
        <Loading />
      ) : load.error ? (
        <ErrorState error={load.error} retry={reload} />
      ) : items.length === 0 ? (
        <Empty
          title={t('Здесь пока пусто')}
          text={
            demo
              ? t('В деморежиме примеры находятся во вкладке «Фото».')
              : tab === 'inventory'
                ? t('Предметы, полученные в VRChat, появятся здесь.')
                : t('Загрузите изображение или добавьте его в VRChat.')
          }
          icon={<ImageIcon size={32} />}
        />
      ) : (
        <div className="grid inventory-grid">
          {items.map((item) => (
            <button
              key={item.id}
              className="card media-card"
              onClick={() => {
                setSelected(item);
                setDeleteConfirm(false);
                setAppearanceAction(null);
              }}
            >
              <div
                className={`media-cover inventory-cover ${tab === 'icon' || tab === 'emoji' || tab === 'sticker' ? 'contain' : ''}`}
              >
                <ImageIcon className="inventory-image-placeholder" size={38} />
                <CollectionPreview
                  src={item.image}
                  alt=""
                  refreshKey={`${pageKey}:${mediaRevision}`}
                />
                <div className="inventory-image-badges">
                  {item.tags.includes('emojianimated') && <Badge>{t('АНИМ.')}</Badge>}
                  {tab === 'inventory' && item.tags[0] && <Badge>{item.tags[0]}</Badge>}
                </div>
              </div>
              <div className="card-body">
                <h3>{collectionName(item)}</h3>
                <p className="muted">
                  {item.createdAt
                    ? dateLabel(item.createdAt, { day: 'numeric', month: 'short', year: 'numeric' })
                    : item.kind === 'inventory'
                      ? t('Предмет VRChat')
                      : t('Изображение')}
                  {item.size ? ` · ${fileSize(item.size)}` : ''}
                </p>
              </div>
            </button>
          ))}
        </div>
      )}
      {!load.loading && hasMore && (
        <button className="button secondary load-more" onClick={more} disabled={busy}>
          {busy ? t('Загрузка…') : t('Загрузить ещё')}
        </button>
      )}
      {selected && (
        <Modal
          title={
            deleteConfirm
              ? t('Удалить файл?')
              : appearanceAction === 'icon'
                ? t('Изменить иконку профиля?')
                : appearanceAction === 'banner'
                  ? t('Изменить баннер профиля?')
                  : collectionName(selected)
          }
          onClose={() => {
            if (!busy) {
              setSelected(null);
              setDeleteConfirm(false);
              setAppearanceAction(null);
            }
          }}
        >
          {deleteConfirm ? (
            <div className="form-stack">
              <p>
                {t('«{name}» будет удалён из VRChat. Это действие нельзя отменить.', {
                  name: collectionName(selected),
                })}
              </p>
              <div className="detail-actions">
                <button className="button danger" onClick={remove} disabled={busy}>
                  <Trash2 size={17} />
                  {busy ? t('Удаление…') : t('Удалить навсегда')}
                </button>
                <button
                  className="button secondary"
                  onClick={() => setDeleteConfirm(false)}
                  disabled={busy}
                >
                  {t('Отмена')}
                </button>
              </div>
            </div>
          ) : appearanceAction ? (
            <div className="form-stack">
              <div className={`appearance-preview ${appearanceAction}`}>
                <SecureImage src={selected.image} alt={collectionName(selected)} />
              </div>
              <p>
                {appearanceAction === 'icon'
                  ? t('Использовать «{name}» как иконку профиля VRChat?', {
                      name: collectionName(selected),
                    })
                  : t('Использовать «{name}» как баннер профиля VRChat?', {
                      name: collectionName(selected),
                    })}
              </p>
              <p className="muted">
                {t('Изменение увидят другие пользователи. Функция требует VRC+.')}
              </p>
              <div className="detail-actions">
                <button
                  className="button"
                  disabled={busy || (!demo && !hasPlus)}
                  onClick={applyAppearance}
                >
                  {busy ? t('Сохранение…') : t('Применить')}
                </button>
                <button
                  className="button secondary"
                  disabled={busy}
                  onClick={() => setAppearanceAction(null)}
                >
                  {t('Отмена')}
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="collection-image-view">
                {selected.image ? (
                  <CollectionPreview
                    src={selected.sourceUrl || selected.image}
                    alt={collectionName(selected)}
                    refreshKey={`${pageKey}:${mediaRevision}`}
                    interactive
                    onOpen={() => void original()}
                  />
                ) : (
                  <Empty title={t('Нет изображения')} />
                )}
              </div>
              <div className="form-stack">
                {selected.createdAt && <p className="muted">{dateLabel(selected.createdAt)}</p>}
                {selected.authorName && (
                  <p className="muted">
                    {t('Автор: ')}
                    {selected.authorName}
                  </p>
                )}
                {selected.worldName && <p>{selected.worldName}</p>}
                {(selected.kind === 'icon' || selected.kind === 'gallery') &&
                  validProfileImage(selected) && (
                    <div className="appearance-actions">
                      <p className="muted">{t('Оформление профиля · VRC+')}</p>
                      <div className="detail-actions">
                        {selected.kind === 'icon' && (
                          <button
                            className="button"
                            disabled={!demo && !hasPlus}
                            onClick={() => setAppearanceAction('icon')}
                          >
                            {t('Сделать иконкой профиля')}
                          </button>
                        )}
                        {selected.kind === 'gallery' && (
                          <button
                            className="button"
                            disabled={!demo && !hasPlus}
                            onClick={() => setAppearanceAction('banner')}
                          >
                            {t('Сделать баннером профиля')}
                          </button>
                        )}
                      </div>
                    </div>
                  )}
                <div className="detail-actions">
                  {selected.image && (
                    <button className="button secondary" onClick={original}>
                      <ExternalLink size={16} />
                      {t('На весь экран')}
                    </button>
                  )}
                  {selected.worldId && (
                    <button
                      className="button secondary"
                      onClick={() => {
                        setSelected(null);
                        openWorld(selected.worldId!);
                      }}
                    >
                      {t('Мир на фото')}
                    </button>
                  )}
                  {selected.kind !== 'inventory' && (
                    <button className="button danger" onClick={() => setDeleteConfirm(true)}>
                      <Trash2 size={16} />
                      {t('Удалить')}
                    </button>
                  )}
                </div>
              </div>
            </>
          )}
        </Modal>
      )}
      {viewer && (
        <FullscreenImageViewer
          src={viewer.src}
          originalUrl={viewer.originalUrl}
          title={viewer.title}
          onClose={() => setViewer(null)}
        />
      )}
      {upload && canUpload && (
        <UploadDialog
          tag={tab as UploadTag}
          onClose={() => setUpload(false)}
          onUpload={async (file) => {
            const kind = tab as UploadTag;
            const uploaded = await act(
              () => api.uploadImage(file, kind),
              uiMessage('Изображение загружено'),
            );
            if (uploaded) {
              setUpload(false);
              load.reload();
              setDeleteConfirm(false);
              setAppearanceAction(null);
              const item = fileItem(uploaded, kind);
              if (item.sourceUrl) setSelected(item);
              else if (uploaded.id) {
                try {
                  setSelected(fileItem(await api.file(uploaded.id), kind));
                } catch {
                  notify(t('Изображение загружено. Обновите список, чтобы открыть его свойства.'));
                }
              }
            }
          }}
        />
      )}
    </>
  );
}

async function normalizeImage(file: File, tag: UploadTag): Promise<File> {
  if (!['image/png', 'image/jpeg', 'image/webp'].includes(file.type))
    throw new Error(t('Выберите PNG, JPEG или WebP.'));
  if (file.size > 10 * 1024 * 1024) throw new Error(t('Исходный файл должен быть меньше 10 МБ.'));
  const url = URL.createObjectURL(file);
  try {
    const image = await new Promise<HTMLImageElement>((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error(t('Не удалось прочитать изображение.')));
      img.src = url;
    });
    if (image.naturalWidth < 64 || image.naturalHeight < 64)
      throw new Error(t('Изображение должно быть не меньше 64 × 64 пикселей.'));
    const square = tag !== 'gallery',
      target = tag === 'emoji' || tag === 'sticker' ? 1024 : 2048;
    const sourceWidth = square
      ? Math.min(image.naturalWidth, image.naturalHeight)
      : image.naturalWidth;
    const sourceHeight = square ? sourceWidth : image.naturalHeight;
    const scale = Math.min(1, target / Math.max(sourceWidth, sourceHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(sourceWidth * scale);
    canvas.height = Math.round(sourceHeight * scale);
    if (tag === 'emoji') {
      canvas.width = 1024;
      canvas.height = 1024;
    }
    if (canvas.width < 64 || canvas.height < 64)
      throw new Error(
        t(
          'Изображение слишком вытянутое. После уменьшения каждая сторона должна быть не меньше 64 пикселей.',
        ),
      );
    const context = canvas.getContext('2d');
    if (!context) throw new Error(t('Не удалось подготовить изображение.'));
    context.drawImage(
      image,
      (image.naturalWidth - sourceWidth) / 2,
      (image.naturalHeight - sourceHeight) / 2,
      sourceWidth,
      sourceHeight,
      0,
      0,
      canvas.width,
      canvas.height,
    );
    const blob = await new Promise<Blob>((resolve, reject) =>
      canvas.toBlob(
        (value) => (value ? resolve(value) : reject(new Error(t('Не удалось сохранить PNG.')))),
        'image/png',
      ),
    );
    if (blob.size > 8 * 1024 * 1024)
      throw new Error(
        t('PNG после обработки превышает 8 МБ. Выберите изображение меньшего размера.'),
      );
    return new File([blob], `${file.name.replace(/\.[^.]+$/, '')}.png`, { type: 'image/png' });
  } finally {
    URL.revokeObjectURL(url);
  }
}
function UploadDialog({
  tag,
  onClose,
  onUpload,
}: {
  tag: UploadTag;
  onClose: () => void;
  onUpload: (file: File) => Promise<void>;
}) {
  useI18n();
  const [file, setFile] = useState<File | null>(null),
    [preview, setPreview] = useState(''),
    [error, setError] = useState(''),
    [busy, setBusy] = useState(false);
  useEffect(
    () => () => {
      if (preview) URL.revokeObjectURL(preview);
    },
    [preview],
  );
  async function choose(event: ChangeEvent<HTMLInputElement>) {
    const selected = event.target.files?.[0];
    if (!selected) return;
    setBusy(true);
    setError('');
    setFile(null);
    setPreview('');
    try {
      const result = await normalizeImage(selected, tag);
      setFile(result);
      setPreview(URL.createObjectURL(result));
    } catch (error) {
      setError(error instanceof Error ? error.message : t('Не удалось обработать изображение'));
    } finally {
      setBusy(false);
    }
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (!file || busy) return;
    setBusy(true);
    try {
      await onUpload(file);
    } finally {
      setBusy(false);
    }
  }
  return (
    <Modal
      title={t('Загрузить изображение')}
      onClose={() => {
        if (!busy) onClose();
      }}
    >
      <form className="form-stack" onSubmit={submit}>
        <p className="muted">
          {tag === 'gallery'
            ? t('До 2048 × 2048, в формате PNG.')
            : tag === 'emoji'
              ? t('Изображение будет обрезано по центру до квадрата 1024 × 1024.')
              : t('Изображение будет обрезано по центру до квадрата.')}{' '}
          {t('Подготовленный файл можно проверить перед загрузкой.')}
        </p>
        <label className="upload-picker">
          <Upload size={24} />
          <span>{busy ? t('Подготовка…') : t('Выбрать изображение')}</span>
          <input
            type="file"
            accept="image/png,image/jpeg,image/webp"
            onChange={choose}
            disabled={busy}
          />
        </label>
        {preview && (
          <>
            <SecureImage
              className="upload-preview"
              src={preview}
              alt={t('Предпросмотр подготовленного изображения')}
            />
            <p className="muted">PNG · {fileSize(file?.size)}</p>
          </>
        )}
        {error && (
          <p className="inline-error" role="alert">
            {error}
          </p>
        )}
        <div className="detail-actions">
          <button className="button" type="submit" disabled={!file || busy}>
            <Upload size={17} />
            {busy ? t('Обработка…') : t('Загрузить в VRChat')}
          </button>
          <button className="button secondary" type="button" onClick={onClose} disabled={busy}>
            {t('Отмена')}
          </button>
        </div>
      </form>
    </Modal>
  );
}

export function MessengerPage() {
  useI18n();
  const { user, demo, act, notify, refresh, openUser } = useApp();
  const [search, setSearch] = useState(''),
    [recipient, setRecipient] = useState<User | null>(null),
    [message, setMessage] = useState(''),
    [sending, setSending] = useState(false),
    [receipt, setReceipt] = useState('');
  const friendsLoad = useLoad<User[]>(
    async () => (demo ? demoFriends : api.allFriends()),
    [user.id, demo, refresh],
  );
  const incomingLoad = useLoad<Notification[]>(
    async () => (demo ? [] : api.notifications()),
    [user.id, demo, refresh],
  );
  const incoming = (incomingLoad.data || [])
    .map((item) => ({
      notification: item,
      text:
        typeof item.details?.inviteMessage === 'string'
          ? item.details.inviteMessage
          : item.message || '',
    }))
    .filter((item) => item.text.startsWith('msg '));
  const slotsLoad = useLoad<MessageTemplate[]>(
    async () =>
      demo
        ? Array.from({ length: 12 }, (_, slot) => ({
            slot,
            message: '',
            canBeUpdated: true,
            remainingCooldownMinutes: 0,
          }))
        : api.messageTemplates(user.id),
    [user.id, demo, refresh],
  );
  const friends = (friendsLoad.data || []).filter((friend) =>
    friend.displayName.toLocaleLowerCase().includes(search.toLocaleLowerCase()),
  );
  const freeSlots = (slotsLoad.data || []).filter(
    (slot) => slot.canBeUpdated && (slot.remainingCooldownMinutes || 0) <= 0,
  ).length;
  const reusedSlot = (slotsLoad.data || []).some(
    (slot) => slot.message === `msg ${message.trim()}`,
  );
  const noSlots = !slotsLoad.loading && !slotsLoad.error && freeSlots === 0 && !reusedSlot;
  async function send(event: FormEvent) {
    event.preventDefault();
    if (!recipient || sending || !message.trim()) return;
    setSending(true);
    setReceipt('');
    try {
      const name = recipient.displayName;
      const success = await act(
        async () => {
          await api.sendMessage(user.id, recipient.id, message.trim());
          return true;
        },
        uiMessage('Сообщение для {value0} отправлено', { value0: name }),
      );
      if (success) {
        setReceipt(
          t('VRChat принял сообщение для {value0}. Оно придёт как приглашение с текстом.', {
            value0: name,
          }),
        );
        setMessage('');
        slotsLoad.reload();
      }
    } catch (error) {
      notify(error instanceof Error ? error.message : t('Не удалось отправить сообщение'));
    } finally {
      setSending(false);
    }
  }
  return (
    <>
      <PageHeader
        eyebrow={t('ОСТАВАЙТЕСЬ НА СВЯЗИ')}
        title={t('Сообщения')}
        subtitle={t('Короткое сообщение другу через приглашение VRChat.')}
      />
      <div className="collection-note messenger-info">
        <Info size={19} />
        <p>
          {t(
            'Как и в ПК-версии, текст отправляется через шаблон приглашения VRChat. Это не обычный чат. VRChat ограничивает изменение шаблонов; отправка возможна только в доступный слот.',
          )}
        </p>
      </div>
      <div className="messenger-layout">
        <section className="card messenger-friends">
          <div className="messenger-friends-heading">
            <h2>{t('Кому написать')}</h2>
            <SearchField value={search} onChange={setSearch} placeholder={t('Найти друга')} />
          </div>
          {friendsLoad.loading ? (
            <Loading />
          ) : friendsLoad.error ? (
            <ErrorState error={friendsLoad.error} retry={friendsLoad.reload} />
          ) : friends.length === 0 ? (
            <Empty
              title={t('Друзья не найдены')}
              text={t('Попробуйте другое имя.')}
              icon={<Users size={28} />}
            />
          ) : (
            <div className="messenger-friend-list">
              {friends.map((friend) => (
                <button
                  className={`list-row messenger-friend ${recipient?.id === friend.id ? 'selected' : ''}`}
                  key={friend.id}
                  onClick={() => {
                    setRecipient(friend);
                    setReceipt('');
                  }}
                  aria-pressed={recipient?.id === friend.id}
                >
                  <AvatarImage
                    name={friend.displayName}
                    src={imageOf(friend)}
                    size={42}
                    user={friend}
                    fallbackSrc={
                      friend.currentAvatarThumbnailImageUrl || friend.currentAvatarImageUrl
                    }
                  />
                  <div>
                    <strong>{friend.displayName}</strong>
                    <p className="muted">{friend.statusDescription || t('Друг в VRChat')}</p>
                  </div>
                  {recipient?.id === friend.id && <Check size={18} />}
                </button>
              ))}
            </div>
          )}
        </section>
        <section className="card messenger-composer">
          {recipient ? (
            <>
              <div className="messenger-recipient">
                <AvatarImage src={imageOf(recipient)} name={recipient.displayName} size={48} />
                <div>
                  <h2>{recipient.displayName}</h2>
                  <button className="text-button" onClick={() => openUser(recipient)}>
                    {t('Открыть профиль')}
                  </button>
                </div>
              </div>
              <form className="form-stack" onSubmit={send}>
                <label className="field">
                  {t('Сообщение')}
                  <textarea
                    value={message}
                    onChange={(event) => setMessage(event.target.value)}
                    maxLength={60}
                    placeholder={t('Привет! Исследуем новые миры вечером?')}
                    rows={4}
                    disabled={sending}
                  />
                </label>
                <div className="composer-meta">
                  <span>{message.length}/60</span>
                  <span>
                    {t('Изменяемых слотов: ')}
                    {slotsLoad.loading ? '…' : freeSlots}
                  </span>
                </div>
                {slotsLoad.error && <ErrorState error={slotsLoad.error} retry={slotsLoad.reload} />}{' '}
                {noSlots && (
                  <p className="collection-note">
                    <Clock3 size={17} />
                    {t(
                      'Все слоты на паузе. Дождитесь окончания ограничения VRChat или используйте уже сохранённый текст.',
                    )}
                  </p>
                )}
                {receipt && (
                  <p className="message-receipt" role="status">
                    <Check size={18} />
                    {receipt}
                  </p>
                )}
                <button
                  className="button"
                  type="submit"
                  disabled={
                    sending || !message.trim() || slotsLoad.loading || !!slotsLoad.error || noSlots
                  }
                >
                  <Send size={17} />
                  {sending ? t('Отправка…') : t('Отправить')}
                </button>
                <p className="muted messenger-cooldown">
                  {t(
                    'Не повторяйте отправку часто. Доступность слотов и время ожидания определяет VRChat.',
                  )}
                </p>
              </form>
            </>
          ) : (
            <Empty
              title={t('Выберите друга')}
              text={t('Одного короткого сообщения бывает достаточно, чтобы собраться вместе.')}
              icon={<Mail size={34} />}
            />
          )}
        </section>
      </div>
      <Section title={t('Полученные сообщения')}>
        {incomingLoad.loading ? (
          <Loading />
        ) : incomingLoad.error ? (
          <ErrorState error={incomingLoad.error} retry={incomingLoad.reload} />
        ) : incoming.length === 0 ? (
          <Empty
            title={t('Новых сообщений нет')}
            text={t(
              'Здесь появятся приглашения с сообщениями VRCNext. Остальные приглашения находятся в уведомлениях.',
            )}
            icon={<Mail size={26} />}
          />
        ) : (
          <div className="event-list">
            {incoming.map(({ notification, text }) => (
              <article className="card incoming-message" key={notification.id}>
                <div className="row">
                  <strong>
                    {notification.senderDisplayName ||
                      notification.senderUsername ||
                      t('Пользователь VRChat')}
                  </strong>
                  <small className="muted">
                    {dateLabel(notification.created_at || notification.createdAt)}
                  </small>
                </div>
                <p>{text.slice(4)}</p>
                {notification.senderUserId && (
                  <button
                    className="text-button"
                    onClick={() => openUser(notification.senderUserId!)}
                  >
                    {t('Открыть профиль')}
                  </button>
                )}
              </article>
            ))}
          </div>
        )}
      </Section>
      <Section title={t('Шаблоны приглашений')}>
        <div className="card message-templates">
          {slotsLoad.loading ? (
            <Loading />
          ) : slotsLoad.error ? (
            <ErrorState error={slotsLoad.error} retry={slotsLoad.reload} />
          ) : (
            <>
              <p className="muted">
                {t(
                  'Сохранённые тексты принадлежат вашему аккаунту VRChat. Изменение при отправке может заменить один из доступных шаблонов.',
                )}
              </p>
              <div className="template-grid">
                {(slotsLoad.data || []).map((slot) => (
                  <button
                    key={slot.slot}
                    className="template-item"
                    onClick={() => {
                      if (slot.message.startsWith('msg ')) setMessage(slot.message.slice(4));
                      else
                        notify(
                          t('Этот шаблон не создан мессенджером и не будет выбран автоматически.'),
                        );
                    }}
                    disabled={!slot.message.startsWith('msg ')}
                  >
                    <span className="row">
                      <Badge>#{slot.slot + 1}</Badge>
                      <small className="muted">
                        {slot.canBeUpdated && (slot.remainingCooldownMinutes || 0) <= 0
                          ? t('Доступен')
                          : t('{value0} мин.', { value0: slot.remainingCooldownMinutes || '—' })}
                      </small>
                    </span>
                    <span>
                      {slot.message.startsWith('msg ')
                        ? slot.message.slice(4)
                        : slot.message || t('Пустой шаблон')}
                    </span>
                  </button>
                ))}
              </div>
            </>
          )}
        </div>
      </Section>
    </>
  );
}
